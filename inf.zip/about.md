# kAd Messenger

* kAd messenger is a private app that is a mod for telegram. It's a little bit worse, but something can be fixed nowadays.