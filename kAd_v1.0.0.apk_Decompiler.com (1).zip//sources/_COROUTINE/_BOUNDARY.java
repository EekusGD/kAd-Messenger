package _COROUTINE;

abstract class _BOUNDARY {
}
