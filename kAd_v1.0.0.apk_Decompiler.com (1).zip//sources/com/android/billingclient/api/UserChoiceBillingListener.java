package com.android.billingclient.api;

public interface UserChoiceBillingListener {
}
