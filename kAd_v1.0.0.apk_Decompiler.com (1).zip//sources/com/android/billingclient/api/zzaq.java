package com.android.billingclient.api;

import com.google.android.gms.internal.play_billing.zzai;
import java.util.concurrent.Callable;

final class zzaq implements Callable {
    final /* synthetic */ String zza;
    final /* synthetic */ PurchasesResponseListener zzb;
    final /* synthetic */ BillingClientImpl zzc;

    zzaq(BillingClientImpl billingClientImpl, String str, PurchasesResponseListener purchasesResponseListener) {
        this.zza = str;
        this.zzb = purchasesResponseListener;
        this.zzc = billingClientImpl;
    }

    public final /* bridge */ /* synthetic */ Object call() {
        zzcx zzaf = BillingClientImpl.zzaf(this.zzc, this.zza, 9);
        if (zzaf.zzb() != null) {
            this.zzb.onQueryPurchasesResponse(zzaf.zza(), zzaf.zzb());
            return null;
        }
        this.zzb.onQueryPurchasesResponse(zzaf.zza(), zzai.zzk());
        return null;
    }
}
