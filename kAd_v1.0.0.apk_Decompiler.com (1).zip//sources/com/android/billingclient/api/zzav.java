package com.android.billingclient.api;

import java.util.concurrent.Callable;

public final /* synthetic */ class zzav implements Callable {
    public final /* synthetic */ zzay zza;

    public /* synthetic */ zzav(zzay zzay) {
        this.zza = zzay;
    }

    public final Object call() {
        this.zza.zza();
        return null;
    }
}
