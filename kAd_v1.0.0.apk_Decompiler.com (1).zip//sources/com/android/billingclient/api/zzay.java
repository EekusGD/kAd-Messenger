package com.android.billingclient.api;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import com.google.android.gms.internal.play_billing.zzb;
import com.google.android.gms.internal.play_billing.zzhs;
import com.google.android.gms.internal.play_billing.zzr;

final class zzay implements ServiceConnection {
    final /* synthetic */ BillingClientImpl zza;
    private final Object zzb = new Object();
    private boolean zzc = false;
    private BillingClientStateListener zzd;

    /* synthetic */ zzay(BillingClientImpl billingClientImpl, BillingClientStateListener billingClientStateListener, zzax zzax) {
        this.zza = billingClientImpl;
        this.zzd = billingClientStateListener;
    }

    private final void zzd(BillingResult billingResult) {
        synchronized (this.zzb) {
            try {
                BillingClientStateListener billingClientStateListener = this.zzd;
                if (billingClientStateListener != null) {
                    billingClientStateListener.onBillingSetupFinished(billingResult);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        zzb.zzj("BillingClient", "Billing service connected.");
        this.zza.zzg = zzr.zzu(iBinder);
        zzav zzav = new zzav(this);
        zzaw zzaw = new zzaw(this);
        BillingClientImpl billingClientImpl = this.zza;
        if (billingClientImpl.zzak(zzav, 30000, zzaw, billingClientImpl.zzag()) == null) {
            BillingClientImpl billingClientImpl2 = this.zza;
            BillingResult zzi = billingClientImpl2.zzai();
            billingClientImpl2.zzf.zza(zzbx.zzb(25, 6, zzi));
            zzd(zzi);
        }
    }

    public final void onServiceDisconnected(ComponentName componentName) {
        zzb.zzk("BillingClient", "Billing service disconnected.");
        this.zza.zzf.zzd(zzhs.zzA());
        this.zza.zzg = null;
        this.zza.zza = 0;
        synchronized (this.zzb) {
            try {
                BillingClientStateListener billingClientStateListener = this.zzd;
                if (billingClientStateListener != null) {
                    billingClientStateListener.onBillingServiceDisconnected();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:116:0x01fd  */
    /* JADX WARNING: Removed duplicated region for block: B:117:0x0202  */
    /* JADX WARNING: Removed duplicated region for block: B:127:0x022b  */
    /* JADX WARNING: Removed duplicated region for block: B:128:0x0238  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final /* synthetic */ java.lang.Object zza() {
        /*
            r14 = this;
            java.lang.Object r0 = r14.zzb
            monitor-enter(r0)
            boolean r1 = r14.zzc     // Catch:{ all -> 0x000b }
            r2 = 0
            if (r1 == 0) goto L_0x000e
            monitor-exit(r0)     // Catch:{ all -> 0x000b }
            goto L_0x0244
        L_0x000b:
            r1 = move-exception
            goto L_0x0245
        L_0x000e:
            monitor-exit(r0)     // Catch:{ all -> 0x000b }
            boolean r0 = android.text.TextUtils.isEmpty(r2)
            if (r0 != 0) goto L_0x0020
            android.os.Bundle r0 = new android.os.Bundle
            r0.<init>()
            java.lang.String r1 = "accountName"
            r0.putString(r1, r2)
            goto L_0x0021
        L_0x0020:
            r0 = r2
        L_0x0021:
            r1 = 6
            r3 = 3
            r4 = 0
            com.android.billingclient.api.BillingClientImpl r5 = r14.zza     // Catch:{ Exception -> 0x01f1 }
            android.content.Context r5 = r5.zze     // Catch:{ Exception -> 0x01f1 }
            java.lang.String r5 = r5.getPackageName()     // Catch:{ Exception -> 0x01f1 }
            r6 = 22
            r7 = 22
            r8 = 3
        L_0x0033:
            if (r7 < r3) goto L_0x0070
            if (r0 != 0) goto L_0x0044
            com.android.billingclient.api.BillingClientImpl r9 = r14.zza     // Catch:{ Exception -> 0x0069 }
            com.google.android.gms.internal.play_billing.zzs r9 = r9.zzg     // Catch:{ Exception -> 0x0069 }
            java.lang.String r10 = "subs"
            int r8 = r9.zzy(r7, r5, r10)     // Catch:{ Exception -> 0x0069 }
            goto L_0x0050
        L_0x0044:
            com.android.billingclient.api.BillingClientImpl r9 = r14.zza     // Catch:{ Exception -> 0x0069 }
            com.google.android.gms.internal.play_billing.zzs r9 = r9.zzg     // Catch:{ Exception -> 0x0069 }
            java.lang.String r10 = "subs"
            int r8 = r9.zzc(r7, r5, r10, r0)     // Catch:{ Exception -> 0x0069 }
        L_0x0050:
            if (r8 != 0) goto L_0x006d
            java.lang.String r9 = "BillingClient"
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0069 }
            r10.<init>()     // Catch:{ Exception -> 0x0069 }
            java.lang.String r11 = "highestLevelSupportedForSubs: "
            r10.append(r11)     // Catch:{ Exception -> 0x0069 }
            r10.append(r7)     // Catch:{ Exception -> 0x0069 }
            java.lang.String r10 = r10.toString()     // Catch:{ Exception -> 0x0069 }
            com.google.android.gms.internal.play_billing.zzb.zzj(r9, r10)     // Catch:{ Exception -> 0x0069 }
            goto L_0x0071
        L_0x0069:
            r0 = move-exception
            r3 = r8
            goto L_0x01f2
        L_0x006d:
            int r7 = r7 + -1
            goto L_0x0033
        L_0x0070:
            r7 = 0
        L_0x0071:
            com.android.billingclient.api.BillingClientImpl r9 = r14.zza     // Catch:{ Exception -> 0x0069 }
            r10 = 5
            r11 = 1
            if (r7 < r10) goto L_0x0079
            r10 = 1
            goto L_0x007a
        L_0x0079:
            r10 = 0
        L_0x007a:
            r9.zzj = r10     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.BillingClientImpl r9 = r14.zza     // Catch:{ Exception -> 0x0069 }
            if (r7 < r3) goto L_0x0083
            r10 = 1
            goto L_0x0084
        L_0x0083:
            r10 = 0
        L_0x0084:
            r9.zzi = r10     // Catch:{ Exception -> 0x0069 }
            r9 = 9
            if (r7 >= r3) goto L_0x0095
            java.lang.String r7 = "BillingClient"
            java.lang.String r10 = "In-app billing API does not support subscription on this device."
            com.google.android.gms.internal.play_billing.zzb.zzj(r7, r10)     // Catch:{ Exception -> 0x0069 }
            r7 = 9
            goto L_0x0096
        L_0x0095:
            r7 = 1
        L_0x0096:
            r10 = 22
        L_0x0098:
            if (r10 < r3) goto L_0x00dc
            if (r0 != 0) goto L_0x00a9
            com.android.billingclient.api.BillingClientImpl r12 = r14.zza     // Catch:{ Exception -> 0x0069 }
            com.google.android.gms.internal.play_billing.zzs r12 = r12.zzg     // Catch:{ Exception -> 0x0069 }
            java.lang.String r13 = "inapp"
            int r8 = r12.zzy(r10, r5, r13)     // Catch:{ Exception -> 0x0069 }
            goto L_0x00b5
        L_0x00a9:
            com.android.billingclient.api.BillingClientImpl r12 = r14.zza     // Catch:{ Exception -> 0x0069 }
            com.google.android.gms.internal.play_billing.zzs r12 = r12.zzg     // Catch:{ Exception -> 0x0069 }
            java.lang.String r13 = "inapp"
            int r8 = r12.zzc(r10, r5, r13, r0)     // Catch:{ Exception -> 0x0069 }
        L_0x00b5:
            if (r8 != 0) goto L_0x00d9
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            r0.zzk = r10     // Catch:{ Exception -> 0x0069 }
            java.lang.String r0 = "BillingClient"
            com.android.billingclient.api.BillingClientImpl r5 = r14.zza     // Catch:{ Exception -> 0x0069 }
            int r5 = r5.zzk     // Catch:{ Exception -> 0x0069 }
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0069 }
            r10.<init>()     // Catch:{ Exception -> 0x0069 }
            java.lang.String r12 = "mHighestLevelSupportedForInApp: "
            r10.append(r12)     // Catch:{ Exception -> 0x0069 }
            r10.append(r5)     // Catch:{ Exception -> 0x0069 }
            java.lang.String r5 = r10.toString()     // Catch:{ Exception -> 0x0069 }
            com.google.android.gms.internal.play_billing.zzb.zzj(r0, r5)     // Catch:{ Exception -> 0x0069 }
            goto L_0x00dc
        L_0x00d9:
            int r10 = r10 + -1
            goto L_0x0098
        L_0x00dc:
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            int r5 = r0.zzk     // Catch:{ Exception -> 0x0069 }
            if (r5 < r6) goto L_0x00e6
            r5 = 1
            goto L_0x00e7
        L_0x00e6:
            r5 = 0
        L_0x00e7:
            r0.zzy = r5     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            int r5 = r0.zzk     // Catch:{ Exception -> 0x0069 }
            r6 = 21
            if (r5 < r6) goto L_0x00f6
            r5 = 1
            goto L_0x00f7
        L_0x00f6:
            r5 = 0
        L_0x00f7:
            r0.zzx = r5     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            int r5 = r0.zzk     // Catch:{ Exception -> 0x0069 }
            r6 = 20
            if (r5 < r6) goto L_0x0106
            r5 = 1
            goto L_0x0107
        L_0x0106:
            r5 = 0
        L_0x0107:
            r0.zzw = r5     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            int r5 = r0.zzk     // Catch:{ Exception -> 0x0069 }
            r6 = 19
            if (r5 < r6) goto L_0x0116
            r5 = 1
            goto L_0x0117
        L_0x0116:
            r5 = 0
        L_0x0117:
            r0.zzv = r5     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            int r5 = r0.zzk     // Catch:{ Exception -> 0x0069 }
            r6 = 18
            if (r5 < r6) goto L_0x0126
            r5 = 1
            goto L_0x0127
        L_0x0126:
            r5 = 0
        L_0x0127:
            r0.zzu = r5     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            int r5 = r0.zzk     // Catch:{ Exception -> 0x0069 }
            r6 = 17
            if (r5 < r6) goto L_0x0136
            r5 = 1
            goto L_0x0137
        L_0x0136:
            r5 = 0
        L_0x0137:
            r0.zzt = r5     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            int r5 = r0.zzk     // Catch:{ Exception -> 0x0069 }
            r6 = 16
            if (r5 < r6) goto L_0x0146
            r5 = 1
            goto L_0x0147
        L_0x0146:
            r5 = 0
        L_0x0147:
            r0.zzs = r5     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            int r5 = r0.zzk     // Catch:{ Exception -> 0x0069 }
            r6 = 15
            if (r5 < r6) goto L_0x0156
            r5 = 1
            goto L_0x0157
        L_0x0156:
            r5 = 0
        L_0x0157:
            r0.zzr = r5     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            int r5 = r0.zzk     // Catch:{ Exception -> 0x0069 }
            r6 = 14
            if (r5 < r6) goto L_0x0166
            r5 = 1
            goto L_0x0167
        L_0x0166:
            r5 = 0
        L_0x0167:
            r0.zzq = r5     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            int r5 = r0.zzk     // Catch:{ Exception -> 0x0069 }
            r6 = 12
            if (r5 < r6) goto L_0x0176
            r5 = 1
            goto L_0x0177
        L_0x0176:
            r5 = 0
        L_0x0177:
            r0.zzp = r5     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            int r5 = r0.zzk     // Catch:{ Exception -> 0x0069 }
            r6 = 10
            if (r5 < r6) goto L_0x0186
            r5 = 1
            goto L_0x0187
        L_0x0186:
            r5 = 0
        L_0x0187:
            r0.zzo = r5     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            int r5 = r0.zzk     // Catch:{ Exception -> 0x0069 }
            if (r5 < r9) goto L_0x0194
            r5 = 1
            goto L_0x0195
        L_0x0194:
            r5 = 0
        L_0x0195:
            r0.zzn = r5     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            int r5 = r0.zzk     // Catch:{ Exception -> 0x0069 }
            r6 = 8
            if (r5 < r6) goto L_0x01a4
            r5 = 1
            goto L_0x01a5
        L_0x01a4:
            r5 = 0
        L_0x01a5:
            r0.zzm = r5     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            int r5 = r0.zzk     // Catch:{ Exception -> 0x0069 }
            if (r5 < r1) goto L_0x01b1
            goto L_0x01b2
        L_0x01b1:
            r11 = 0
        L_0x01b2:
            r0.zzl = r11     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            int r0 = r0.zzk     // Catch:{ Exception -> 0x0069 }
            if (r0 >= r3) goto L_0x01c6
            java.lang.String r0 = "BillingClient"
            java.lang.String r3 = "In-app billing API version 3 is not supported on this device."
            com.google.android.gms.internal.play_billing.zzb.zzk(r0, r3)     // Catch:{ Exception -> 0x0069 }
            r7 = 36
        L_0x01c6:
            if (r8 != 0) goto L_0x01e6
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            r3 = 2
            r0.zza = r3     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.zzk r0 = r0.zzd     // Catch:{ Exception -> 0x0069 }
            if (r0 == 0) goto L_0x0223
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.zzk r0 = r0.zzd     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.BillingClientImpl r3 = r14.zza     // Catch:{ Exception -> 0x0069 }
            boolean r3 = r3.zzx     // Catch:{ Exception -> 0x0069 }
            r0.zzg(r3)     // Catch:{ Exception -> 0x0069 }
            goto L_0x0223
        L_0x01e6:
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            r0.zza = r4     // Catch:{ Exception -> 0x0069 }
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza     // Catch:{ Exception -> 0x0069 }
            r0.zzg = r2     // Catch:{ Exception -> 0x0069 }
            goto L_0x0223
        L_0x01f1:
            r0 = move-exception
        L_0x01f2:
            java.lang.String r5 = "BillingClient"
            java.lang.String r6 = "Exception while checking if billing is supported; try to reconnect"
            com.google.android.gms.internal.play_billing.zzb.zzl(r5, r6, r0)
            boolean r5 = r0 instanceof android.os.DeadObjectException
            if (r5 == 0) goto L_0x0202
            r0 = 101(0x65, float:1.42E-43)
            r7 = 101(0x65, float:1.42E-43)
            goto L_0x0218
        L_0x0202:
            boolean r5 = r0 instanceof android.os.RemoteException
            if (r5 == 0) goto L_0x020b
            r0 = 100
            r7 = 100
            goto L_0x0218
        L_0x020b:
            boolean r0 = r0 instanceof java.lang.SecurityException
            if (r0 == 0) goto L_0x0214
            r0 = 102(0x66, float:1.43E-43)
            r7 = 102(0x66, float:1.43E-43)
            goto L_0x0218
        L_0x0214:
            r0 = 42
            r7 = 42
        L_0x0218:
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza
            r0.zza = r4
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza
            r0.zzg = r2
            r8 = r3
        L_0x0223:
            com.android.billingclient.api.BillingClientImpl r0 = r14.zza
            com.android.billingclient.api.zzby r0 = r0.zzf
            if (r8 != 0) goto L_0x0238
            com.google.android.gms.internal.play_billing.zzgl r1 = com.android.billingclient.api.zzbx.zzd(r1)
            r0.zzb(r1)
            com.android.billingclient.api.BillingResult r0 = com.android.billingclient.api.zzca.zzl
            r14.zzd(r0)
            goto L_0x0244
        L_0x0238:
            com.android.billingclient.api.BillingResult r3 = com.android.billingclient.api.zzca.zza
            com.google.android.gms.internal.play_billing.zzgh r1 = com.android.billingclient.api.zzbx.zzb(r7, r1, r3)
            r0.zza(r1)
            r14.zzd(r3)
        L_0x0244:
            return r2
        L_0x0245:
            monitor-exit(r0)     // Catch:{ all -> 0x000b }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.billingclient.api.zzay.zza():java.lang.Object");
    }

    /* access modifiers changed from: package-private */
    public final /* synthetic */ void zzb() {
        this.zza.zza = 0;
        this.zza.zzg = null;
        zzby zzh = this.zza.zzf;
        BillingResult billingResult = zzca.zzn;
        zzh.zza(zzbx.zzb(24, 6, billingResult));
        zzd(billingResult);
    }
}
