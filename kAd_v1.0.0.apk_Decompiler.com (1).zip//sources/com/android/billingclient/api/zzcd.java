package com.android.billingclient.api;

import android.content.ContentResolver;
import android.content.Context;
import android.provider.Settings;
import com.google.android.gms.internal.play_billing.zzb;
import com.google.android.gms.internal.play_billing.zzbg;
import com.google.android.gms.internal.play_billing.zzbk;
import com.google.android.gms.internal.play_billing.zzcp;
import com.google.android.gms.internal.play_billing.zzgh;
import com.google.android.gms.internal.play_billing.zzgl;
import com.google.android.gms.internal.play_billing.zzgn;
import com.google.android.gms.internal.play_billing.zzgr;
import com.google.android.gms.internal.play_billing.zzgw;
import com.google.android.gms.internal.play_billing.zzgy;
import com.google.android.gms.internal.play_billing.zzhb;
import com.google.android.gms.internal.play_billing.zzhd;
import com.google.android.gms.internal.play_billing.zzhe;
import com.google.android.gms.internal.play_billing.zzhk;
import com.google.android.gms.internal.play_billing.zzhl;
import com.google.android.gms.internal.play_billing.zzhn;
import com.google.android.gms.internal.play_billing.zzho;
import com.google.android.gms.internal.play_billing.zzhs;
import java.util.Iterator;
import java.util.List;

final class zzcd implements zzby {
    private final zzhb zzb;
    private final Context zzc;
    private final zzcf zzd;

    zzcd(Context context, zzhb zzhb) {
        this.zzd = new zzcf(context);
        this.zzb = zzhb;
        this.zzc = context;
    }

    public final void zza(zzgh zzgh) {
        if (zzgh != null) {
            try {
                zzhk zzz = zzhl.zzz();
                zzhb zzhb = this.zzb;
                if (zzhb != null) {
                    zzz.zzl(zzhb);
                }
                zzz.zzi(zzgh);
                this.zzd.zza((zzhl) zzz.zzc());
            } catch (Throwable th) {
                zzb.zzl("BillingLogger", "Unable to log.", th);
            }
        }
    }

    public final void zzb(zzgl zzgl) {
        if (zzgl != null) {
            try {
                zzhk zzz = zzhl.zzz();
                zzhb zzhb = this.zzb;
                if (zzhb != null) {
                    zzz.zzl(zzhb);
                }
                zzz.zzj(zzgl);
                this.zzd.zza((zzhl) zzz.zzc());
            } catch (Throwable th) {
                zzb.zzl("BillingLogger", "Unable to log.", th);
            }
        }
    }

    public final void zzc(byte[] bArr) {
        try {
            zzg(zzgy.zzB(bArr, zzcp.zza()));
        } catch (Throwable th) {
            zzb.zzl("BillingLogger", "Unable to log.", th);
        }
    }

    public final void zzd(zzhs zzhs) {
        if (zzhs != null) {
            try {
                zzhk zzz = zzhl.zzz();
                zzhb zzhb = this.zzb;
                if (zzhb != null) {
                    zzz.zzl(zzhb);
                }
                zzz.zzn(zzhs);
                this.zzd.zza((zzhl) zzz.zzc());
            } catch (Throwable th) {
                zzb.zzl("BillingLogger", "Unable to log.", th);
            }
        }
    }

    public final void zze(int i, List list, boolean z, boolean z2) {
        zzgy zzgy;
        try {
            int i2 = zzbx.$r8$clinit;
            zzgw zzz = zzgy.zzz();
            zzz.zzn(i);
            zzz.zzm(false);
            zzz.zzl(z2);
            zzz.zzi(list);
            zzgy = (zzgy) zzz.zzc();
        } catch (Exception e) {
            zzb.zzl("BillingLogger", "Unable to create logging payload", e);
            zzgy = null;
        } catch (Throwable th) {
            zzb.zzl("BillingLogger", "Unable to log.", th);
            return;
        }
        zzg(zzgy);
    }

    public final void zzf(int i, List list, List list2, BillingResult billingResult, boolean z, boolean z2) {
        zzgy zzgy;
        try {
            int i2 = zzbx.$r8$clinit;
            zzgw zzz = zzgy.zzz();
            zzz.zzn(4);
            zzz.zzi(list);
            zzz.zzm(false);
            zzz.zzl(z2);
            Iterator it = list2.iterator();
            while (it.hasNext()) {
                Purchase purchase = (Purchase) it.next();
                zzhn zzz2 = zzho.zzz();
                zzz2.zzi(purchase.getProducts());
                zzz2.zzk(purchase.getPurchaseState());
                zzz2.zzj(purchase.getPackageName());
                zzz.zzj(zzz2);
            }
            zzgn zzz3 = zzgr.zzz();
            zzz3.zzk(billingResult.getResponseCode());
            zzz3.zzj(billingResult.getDebugMessage());
            zzz.zzk(zzz3);
            zzgy = (zzgy) zzz.zzc();
        } catch (Exception e) {
            zzb.zzl("BillingLogger", "Unable to create logging payload", e);
            zzgy = null;
        } catch (Throwable th) {
            zzb.zzl("BillingLogger", "Unable to log.", th);
            return;
        }
        zzg(zzgy);
    }

    /* access modifiers changed from: package-private */
    public final void zzg(zzgy zzgy) {
        if (zzgy != null) {
            try {
                if (this.zzb != null) {
                    try {
                        Context context = this.zzc;
                        String str = null;
                        ContentResolver contentResolver = context == null ? null : context.getContentResolver();
                        if (contentResolver != null) {
                            str = Settings.Secure.getString(contentResolver, "android_id");
                        }
                        int zza = str == null ? 0 : zzbg.zza().zza(str).zza();
                        int i = zzbk.$r8$clinit;
                        long j = ((long) (zza % 100)) % 100;
                        if (j < 0) {
                            j += 100;
                        }
                        if (((long) ((int) j)) < 0) {
                            zzhk zzz = zzhl.zzz();
                            zzhb zzhb = this.zzb;
                            if (zzhb != null) {
                                zzz.zzl(zzhb);
                            }
                            zzz.zzk(zzgy);
                            zzhd zzz2 = zzhe.zzz();
                            zzdi.zza(this.zzc);
                            zzz2.zzi(false);
                            zzz.zzm(zzz2);
                            this.zzd.zza((zzhl) zzz.zzc());
                        }
                    } catch (Exception unused) {
                    }
                }
            } catch (Throwable th) {
                zzb.zzl("BillingLogger", "Unable to log.", th);
            }
        }
    }
}
