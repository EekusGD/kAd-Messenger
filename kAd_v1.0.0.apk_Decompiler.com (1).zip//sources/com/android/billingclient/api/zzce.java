package com.android.billingclient.api;

import com.google.android.datatransport.Transformer;
import com.google.android.gms.internal.play_billing.zzhl;

public final /* synthetic */ class zzce implements Transformer {
    public static final /* synthetic */ zzce zza = new zzce();

    private /* synthetic */ zzce() {
    }

    public final Object apply(Object obj) {
        return ((zzhl) obj).zzd();
    }
}
