package com.android.billingclient.api;

import org.json.JSONObject;

public final class zzco {
    zzco(JSONObject jSONObject) {
        jSONObject.getInt("commitmentPaymentsCount");
        jSONObject.optInt("subsequentCommitmentPaymentsCount");
    }
}
