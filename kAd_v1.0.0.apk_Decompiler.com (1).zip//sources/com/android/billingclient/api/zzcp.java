package com.android.billingclient.api;

import org.json.JSONObject;

public final class zzcp {
    zzcp(JSONObject jSONObject) {
        jSONObject.getInt("percentageDiscount");
    }
}
