package com.android.billingclient.api;

import org.json.JSONObject;

public final class zzcq {
    zzcq(JSONObject jSONObject) {
        jSONObject.getInt("maximumQuantity");
        jSONObject.getInt("remainingQuantity");
    }
}
