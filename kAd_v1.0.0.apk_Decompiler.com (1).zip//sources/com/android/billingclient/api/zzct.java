package com.android.billingclient.api;

import org.json.JSONObject;

public final class zzct {
    zzct(JSONObject jSONObject) {
        jSONObject.getLong("startTimeMillis");
        jSONObject.getLong("endTimeMillis");
    }
}
