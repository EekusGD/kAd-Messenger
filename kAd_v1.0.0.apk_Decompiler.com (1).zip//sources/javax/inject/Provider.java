package javax.inject;

public interface Provider {
    Object get();
}
